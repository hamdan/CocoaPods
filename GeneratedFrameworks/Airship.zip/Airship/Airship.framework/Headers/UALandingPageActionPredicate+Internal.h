/* Copyright Urban Airship and Contributors */

#import <Foundation/Foundation.h>
#import "UAAirshipAutomationCoreImport.h"

/**
 * Default predicate for the landing page action.
 */
@interface UALandingPageActionPredicate : NSObject<UAActionPredicateProtocol>

@end
