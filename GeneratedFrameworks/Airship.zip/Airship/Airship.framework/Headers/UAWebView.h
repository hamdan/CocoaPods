/* Copyright Airship and Contributors */

#import <WebKit/WebKit.h>

@interface UAWebView : WKWebView

@end
