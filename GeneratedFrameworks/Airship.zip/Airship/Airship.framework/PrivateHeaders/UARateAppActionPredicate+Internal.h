/* Copyright Airship and Contributors */

#import <Foundation/Foundation.h>
#import "UAExtendedActionsCoreImport.h"

/**
 * Default predicate for rate app action.
 */
@interface UARateAppActionPredicate: NSObject<UAActionPredicateProtocol>

@end
