/* Copyright Airship and Contributors */

#import "UARateAppAction.h"
#import "UAExtendedActionsCoreImport.h"

@interface UARateAppAction()

/*
 * System version exposed for testing purposes
 */
@property (nonatomic, strong) UASystemVersion *systemVersion;

@end
