/* Copyright Airship and Contributors */

#import <Foundation/Foundation.h>

@interface UAJSONValueTransformer : NSValueTransformer

@end
