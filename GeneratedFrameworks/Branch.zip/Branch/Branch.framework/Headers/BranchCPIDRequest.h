//
//  BranchCPIDRequest.h
//  Branch
//
//  Created by Ernest Cho on 9/9/19.
//  Copyright © 2019 Branch, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BNCServerRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface BranchCPIDRequest : BNCServerRequest

@end

NS_ASSUME_NONNULL_END
