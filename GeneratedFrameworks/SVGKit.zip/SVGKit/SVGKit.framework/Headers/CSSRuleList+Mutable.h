#import "CSSRuleList.h"

@interface CSSRuleList ()

@property(nonatomic,strong) NSMutableArray* internalArray;

@end
