#import "CSSPrimitiveValue.h"

@interface CSSPrimitiveValue ()

@property(nonatomic) float pixelsPerInch;

@end
