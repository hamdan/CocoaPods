#import <Foundation/Foundation.h>

#import "SVGKParser.h"

@interface SVGKParserSVG : NSObject <SVGKParserExtension> {
}

@end
