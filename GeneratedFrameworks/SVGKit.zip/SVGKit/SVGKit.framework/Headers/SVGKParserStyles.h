//
//  SVGStyleParser.h
//  SVGPad
//
//  Created by Kevin Stich on 2/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SVGKParser.h"

@interface SVGKParserStyles : NSObject <SVGKParserExtension> {
    @private
//    NSSet *_tags, *_namespaces;
}

@end
