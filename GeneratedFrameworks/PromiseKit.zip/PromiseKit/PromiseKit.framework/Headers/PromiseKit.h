#import "fwd.h"
#import "AnyPromise.h"

#import <Foundation/NSObjCRuntime.h>  // `FOUNDATION_EXPORT`

FOUNDATION_EXPORT double PromiseKitVersionNumber;
FOUNDATION_EXPORT const unsigned char PromiseKitVersionString[];
